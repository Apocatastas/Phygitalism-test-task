﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;


public class Controller : MonoBehaviour
{
    public GameObject spherePrefab;
    public GameObject[] balls;
    public Ball[] myballs;
    private Camera[] cameras;
    public int ballcount;
    private int camcount;
    private string jsonContents;

    private int xLen;
    private int yLen;
    private int zLen;
    public int minLen;
    public int routePoint;
    public Vector3 currentRouteStart;




    public class JsonRawData // Storing data from JSON
    {
        public float[] x;
        public float[] y;
        public float[] z;

    };

    public JsonRawData fileOutputClass;

    private void Start()
    {
        // ball = FindObjectOfType<Ball>();
        filePath = "Assets/Resources/ball_path.json";
        jsonContents = File.ReadAllText(filePath);
        fileOutputClass = JsonUtility.FromJson<JsonRawData>(jsonContents);
        ballcount = 4;
        camcount = ballcount;
        balls = new GameObject[ballcount];
        minLen = 0;
        xLen = 0;
        yLen = 0;
        zLen = 0;
        routePoint = 0;
        WhosShorter(); // min length search (if json is not complete)
        Debug.Log("Min Len" + minLen);
        currentRouteStart = Vector3.zero;

        for  (int i = 0; i < ballcount; i++)

                {
            balls[i] = Instantiate(spherePrefab);


        }



    }

    private void Update()
    {

    }

    public Vector3 GetPointByStep(int what)
    {  // Getting next point of route while we got current route step

        Vector3 point = Vector3.zero;
        point.x = fileOutputClass.x[what];
        point.y = fileOutputClass.y[what];
        point.z = fileOutputClass.z[what];
        return point;
    }

    public Vector3 CoordsTransform(Vector3 what)  //Adding start correction to readed route point 
    {
        Vector3 resultTranformation;
        resultTranformation = Vector3.zero;
        resultTranformation.x = currentRouteStart.x + what.x;
        resultTranformation.y = currentRouteStart.y + what.y;
        resultTranformation.z = currentRouteStart.z + what.z;

        return resultTranformation;
    }

    private void WhosShorter()  // Check for shortest data stream if file is not complete. We could only use complete data

    {

        xLen = fileOutputClass.x.Length;
        yLen = fileOutputClass.y.Length;
        zLen = fileOutputClass.z.Length;

        if (xLen > yLen)
        {
            if (yLen > zLen)
            {
                minLen = zLen;
            }
            else
            {
                minLen = yLen;
            }


        }
        else
        {
            if (xLen > zLen)
            {
                minLen = zLen;
            }
            else
            {
                minLen = xLen;
            }

        }
    }

    public void SetCurrentRouteStart(Vector3 what) // Route start setter
    {
        currentRouteStart = what;
    }

}
