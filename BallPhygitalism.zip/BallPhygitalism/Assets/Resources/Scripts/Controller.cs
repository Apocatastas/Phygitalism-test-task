﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

using UnityEngine;


public class Controller : MonoBehaviour //UI controller and common balls instantiation
{
    public GameObject spherePrefab;
    public GameObject[] balls;
    private Camera[] cameras;
    public int ballcount;
    int ballsChecksum;
    public int defaultActiveBall;
    Button[] buttons;

    private void Start()
    {

        ballcount = 4;
        balls = new GameObject[ballcount];
        ballsChecksum = 0;
        defaultActiveBall = 0;


        //BALLS INSTANTIATION

        for (int i = 0; i < ballcount; i++)

        {
            balls[i] = Instantiate(spherePrefab);

            if (i == 0)
            {
                balls[i].GetComponent<Ball>().SetRouteFilePath("Assets/Resources/ball_path.json");
            }
            else
            {
                balls[i].GetComponent<Ball>().SetRouteFilePath("Assets/Resources/ball_path" + (i + 1) + ".json");
            }
            if (balls[i] != null)
            {
                ballsChecksum++;

            }
            balls[i].GetComponent<Ball>().FillRouteData();

        }

        //Buttons instantiation

        buttons = FindObjectsOfType<Button>();
        ButtonsInit();

        //Camera setting

        cameras = Camera.allCameras;
        ShutAllCam();
        cameras[0].enabled = true;
    }

    void ButtonsInit() //every second button is for Right, every first is Left

    {
        for (int i = 0; i < buttons.Length; i++)

        {
            Button temp = buttons[i].GetComponent<Button>();
            if ((i % 2) == 0)
            {
                temp.onClick.AddListener(() => SwitchRight());
            }
            else
            {
                temp.onClick.AddListener(() => SwitchLeft());
            }
        }
    }


    public void CamSwitch(int what)
    {
        int number = WhichCamIsNext(what);
        ShutAllCam();
        cameras[number].enabled = true;
        Debug.Log(Time.fixedTime + "Switched to " + number);
        if (cameras[number].gameObject.GetComponentInParent<Ball>().isMoving)
        { cameras[number].gameObject.GetComponentInChildren<Slider>().value = 0; }

    }

    int WhichCamIsNext(int what)
    {

        for (int i = 0; i < cameras.Length; i++)

        {
            if (cameras[i].isActiveAndEnabled)
            {

                if (what > 0)
                {
                    if (i < 3)
                    {
                        return i + what;
                    }
                    else
                    {
                        return 0;
                    }
                }
                else
                {
                    if (i > 0)
                    {
                        return i + what;
                    }
                    else
                    {
                        return 3;
                    }
                }

            }

        }
        return 0;
    }

    public void SwitchRight()
    {
        CamSwitch(1);
    }

    public void SwitchLeft()
    {
        CamSwitch(-1);
    }

    void ShutAllCam()
    {

        for (int i = 0; i < cameras.Length; i++)

        {
            cameras[i].enabled = false;
        }
    }

}
