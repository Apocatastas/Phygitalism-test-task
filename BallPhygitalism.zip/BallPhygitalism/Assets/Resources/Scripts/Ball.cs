﻿using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Ball : MonoBehaviour, IPointerClickHandler
{
    public bool isMoving;
    public bool isStopped;
    public bool clickHandler;
    private Vector3 nextPosition;
    private Controller controller;
    public float maxDistanceDelta;
    public int counter;
    float doubleClickStart;
    public string filePath;
    private Slider slider;
    private float multiplier;

    private void Start()
    {
        isMoving = false;
        isStopped = false;
        controller = FindObjectOfType<Controller>();
        maxDistanceDelta = 0.5f;
        clickHandler = false;
        counter = 0;
     
        slider = FindObjectOfType<Slider>();
    }

    public void SetMaxDistance() 
    {
        Debug.Log("prev "+maxDistanceDelta+"\n");

        if (Mathf.Abs(multiplier) > 0) { maxDistanceDelta = maxDistanceDelta * multiplier; }; //we ran out of range. 
        //Make a method to maximize and minimize!

        Debug.Log("next " + maxDistanceDelta + "\n");
    }

    private void Update()
    {
   
     multiplier = slider.value;
    if (clickHandler == true) {  Move(); }


    }

    private void Move()
    {
        if (Mathf.Abs(multiplier) > 0)
        {


            if (!isStopped)
            {
                if (controller.routePoint < controller.minLen - 1)
                {
                    SetMaxDistance();

                    isMoving = true;

                    // Debug.Log("point " + controller.routePoint + "\n");
                    //  Debug.Log("we are " + transform.position + "\n");
                    //  Debug.Log("going to " + controller.CoordsTransform(controller.GetPointByStep(controller.routePoint + 1)) + "\n");

                    // Movement into one route point       

                    if (transform.position != controller.CoordsTransform(controller.GetPointByStep(controller.routePoint + 1)))
                    {
                        transform.position = Vector3.MoveTowards(transform.position, controller.CoordsTransform(controller.GetPointByStep(controller.routePoint + 1)), maxDistanceDelta);
                        //    Debug.Log("came to  " + transform.position + "\n");
                    }
                    else
                    {

                        // moving into one point is finished, so we increment to next point

                        controller.routePoint++;
                        counter++;
                        Debug.Log("upd point " + controller.routePoint + " count " + counter + "\n");
                        if (transform.position == controller.CoordsTransform(controller.GetPointByStep(controller.minLen - 1)))
                        {
                            isMoving = false;
                            controller.currentRouteStart = transform.position;
                            clickHandler = false;
                            controller.routePoint = 0;
                            controller.SetCurrentRouteStart(transform.position);
                        }

                    }
                }
            }
        }
    }

    public void OnPointerClick(PointerEventData eventData)
    {
      //  isStopped = false;
        doubleClickStart = Time.time;

        if (eventData.pointerId == -1)  // Get the left click
        {
            if (isMoving == false) { clickHandler = true; }
        }
    }

    public void OnMouseUp()
    {
        float maxDoubleClickTime = 0.5f;

        if ((Time.time - doubleClickStart)<maxDoubleClickTime) 
        {
            transform.position = Vector3.zero;
            isMoving = false;
            clickHandler = false;
            controller.routePoint = 0;
            controller.currentRouteStart = Vector3.zero;
            isStopped = true;
            GetComponent<TrailRenderer>().time = 0;

        }

        else

        {
            isStopped = false;
            doubleClickStart = Time.time;
            GetComponent<TrailRenderer>().time = 500;
        }



    }

}
