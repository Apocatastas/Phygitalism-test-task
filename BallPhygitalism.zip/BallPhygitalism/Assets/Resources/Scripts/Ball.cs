﻿using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using System.IO;


public class Ball : MonoBehaviour, IPointerClickHandler
{
    //AppBindings
    private Slider slider;
    public Controller controller;
    public bool clickHandler;

    //Route mechanics
    public int routePoint;
    public Vector3 currentRouteStart;
    private Vector3 nextPosition;
    public float maxDistanceDelta;
    float doubleClickStart;
    private float multiplier; //speed of moving


    //Ball fields
    public bool isMoving;
    public bool isStopped;

    //Json bindings
    public string filePath;
    public string jsonContents;


    public class JsonRawData // Storing data from JSON in a structure
    {
        public float[] x;
        public float[] y;
        public float[] z;

    };

    public JsonRawData fileOutputClass;

    private void Start()
    {
        isMoving = false;
        isStopped = false;
        controller = FindObjectOfType<Controller>();
        maxDistanceDelta = 0.5f;
        clickHandler = false;
        routePoint = 0;
        fileOutputClass = new JsonRawData();
        currentRouteStart = Vector3.zero;
        slider = FindObjectOfType<Slider>();
        FillRouteData();

    }

    public void SetCurrentRouteStart(Vector3 what) // Route start setter
    {
        currentRouteStart = what;
    }


    public void SetRouteFilePath(string what)
    {

        filePath = what;

    }


    public string GetRouteFilePath()
    {
        return filePath;
    }


    public void SetMaxDistance()
    {

        if (Mathf.Abs(multiplier) > 0)
        {

            maxDistanceDelta = 0.2f * multiplier + 0.05f;

        }
    }



    public Vector3 CoordsTransform(Vector3 what)  //Adding start correction to readed route point 
    {
        Vector3 resultTranformation;
        resultTranformation = Vector3.zero;
        resultTranformation.x = currentRouteStart.x + what.x;
        resultTranformation.y = currentRouteStart.y + what.y;
        resultTranformation.z = currentRouteStart.z + what.z;

        return resultTranformation;
    }


    private void Update()
    {

        multiplier = slider.value;
        if (clickHandler == true) { Move(); }


    }

    private void Move()
    {
        if (Mathf.Abs(multiplier) > 0)
        {
            if (!isStopped)
            {
                if (routePoint < WhosShorter() - 1)
                {
                    SetMaxDistance();
                    isMoving = true;
                    if (transform.position != CoordsTransform(GetPointByStep(routePoint + 1)))
                    {
                        transform.position = Vector3.MoveTowards(transform.position, CoordsTransform(GetPointByStep(routePoint + 1)), maxDistanceDelta);
                    }
                    else
                    {
                        routePoint++;
                        if (transform.position == CoordsTransform(GetPointByStep(WhosShorter() - 1)))
                        {
                            isMoving = false;
                            currentRouteStart = transform.position;
                            clickHandler = false;
                            routePoint = 0;
                            SetCurrentRouteStart(transform.position);
                        }

                    }
                }
            }
        }
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        doubleClickStart = Time.time;
        if (eventData.pointerId == -1)  // Get the left click
        {
            if (isMoving == false) { clickHandler = true; }
        }
    }

    public void OnMouseUp()
    {
        float maxDoubleClickTime = 0.5f;

        if ((Time.time - doubleClickStart) < maxDoubleClickTime)
        {
            transform.position = Vector3.zero;
            isMoving = false;
            clickHandler = false;
            routePoint = 0;
            currentRouteStart = Vector3.zero;
            isStopped = true;
            GetComponent<TrailRenderer>().time = 0;
        }

        else

        {
            isStopped = false;
            doubleClickStart = Time.time;
            GetComponent<TrailRenderer>().time = 500;
        }



    }
    int WhosShorter()  // Check for shortest data stream if file is not complete. We could only use complete data

    {
        int xLen = fileOutputClass.x.Length;
        int yLen = fileOutputClass.y.Length;
        int zLen = fileOutputClass.z.Length;
        int minLen = 0;

        if (xLen > yLen)
        {
            if (yLen > zLen)
            {
                minLen = zLen;
            }
            else
            {
                minLen = yLen;
            }
        }
        else
        {
            if (xLen > zLen)
            {
                minLen = zLen;
            }
            else
            {
                minLen = xLen;
            }
        }

        return minLen;
    }

    public void FillRouteData()
    {
        jsonContents = File.ReadAllText(filePath); //Filling ball field with raw data
        fileOutputClass = JsonUtility.FromJson<JsonRawData>(jsonContents); //Filling common structure for calculating route points
    }

    public Vector3 GetPointByStep(int what)  // Getting next point of ball json route

    {
        Vector3 point = Vector3.zero;
        point.x = fileOutputClass.x[what];
        point.y = fileOutputClass.y[what];
        point.z = fileOutputClass.z[what];
        return point;
    }
}
